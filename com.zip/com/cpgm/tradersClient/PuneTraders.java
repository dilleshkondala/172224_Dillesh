package com.cpgm.tradersClient;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import com.cpgm.streamspojo.Trader;

public class PuneTraders {

	public static void main(String[] args) {
		List<Trader> list=new ArrayList<>();
		list.add(new Trader("dillesh", "Ponduru"));
		list.add(new Trader("mahesh","Hyderabad"));
		list.add(new Trader("Srinivas", "Guntur"));
		list.add(new Trader("Gopi", "Bangalore"));
		list.add(new Trader("Koormi", "Pune"));	
		list.add(new Trader("john", "Ponduru"));
		list.add(new Trader("mamoo","Hyderabad"));
		list.add(new Trader("mikel", "Pune"));
		list.add(new Trader("jason", "Bangalore"));
		list.add(new Trader("ajit", "Pune"));	
		
		List<Trader> cities = list.stream()
				.filter(city -> city.getCity()=="Pune")
				.sorted(Comparator.comparing(Trader::getName))
				.collect(Collectors.toList());
		
		cities.forEach(System.out::println);

	}

}
