package com.cpgm.tradersClient;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import com.cpgm.streamspojo.Trader;

public class AllTradersNames {

	public static void main(String[] args) {
		
		List<Trader> list=new ArrayList<>();
		list.add(new Trader("dillesh", "Ponduru"));
		list.add(new Trader("mahesh","Hyderabad"));
		list.add(new Trader("Srinivas", "Guntur"));
		list.add(new Trader("Gopi", "Bangalore"));
		list.add(new Trader("Koormi", "Chennai"));	
		list.add(new Trader("john", "Ponduru"));
		list.add(new Trader("mamoo","Hyderabad"));
		list.add(new Trader("mikel", "Guntur"));
		list.add(new Trader("jason", "Bangalore"));
		list.add(new Trader("ajit", "Chennai"));	
		
		List<Trader> names = list.stream()
				.sorted(Comparator.comparing(Trader::getName))
				.collect(Collectors.toList());
		String filterdNames = names.stream()
				.map(Trader::getName)
				.collect(Collectors.joining(", "));
		System.out.println(filterdNames);

	}

}
