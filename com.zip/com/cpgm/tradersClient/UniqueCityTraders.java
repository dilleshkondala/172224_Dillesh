package com.cpgm.tradersClient;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import com.cpgm.streamspojo.Trader;

public class UniqueCityTraders {

	public static void main(String[] args) {

		List<Trader> list=new ArrayList<>();
		list.add(new Trader("dillesh", "Ponduru"));
		list.add(new Trader("mahesh","Hyderabad"));
		list.add(new Trader("Srinivas", "Guntur"));
		list.add(new Trader("Gopi", "Bangalore"));
		list.add(new Trader("Koormi", "Chennai"));	
		list.add(new Trader("john", "Ponduru"));
		list.add(new Trader("mamoo","Hyderabad"));
		list.add(new Trader("mikel", "Guntur"));
		list.add(new Trader("jason", "Bangalore"));
		list.add(new Trader("ajit", "Chennai"));	
		
		List<String> cities = list.stream().map(Trader :: getCity).distinct().collect(Collectors.toList());
		cities.forEach(System.out :: println);
		
	}

}
