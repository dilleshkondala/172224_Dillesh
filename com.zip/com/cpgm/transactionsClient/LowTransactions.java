package com.cpgm.transactionsClient;

import java.util.ArrayList;
import java.util.List;

import com.cpgm.streamspojo.Trader;
import com.cpgm.streamspojo.Transaction;

public class LowTransactions {

	public static void main(String[] args) {
		

		Trader trader1 = new Trader("dillesh","Ponduru");
		Trader trader2 = new Trader("Srinivas","Guntur");
		Trader trader3 = new Trader("Vidya","VSKP");
		Trader trader4 = new Trader("gopi","Bangalore");
		
		Transaction transaction1 = new Transaction(trader1,2011,144000);
		Transaction transaction2 = new Transaction(trader2,2002,104300);
		Transaction transaction3 = new Transaction(trader3,2011,300223);
		Transaction transaction4 = new Transaction(trader4,2009,500878);
		Transaction transaction5 = new Transaction(trader1,2009,753430);
		Transaction transaction6 = new Transaction(trader2,2011,308780);
		
		Transaction max2=list.stream()
				.min((p1,p2)->Integer.compare(p1.getValue(), p2.getValue()))
				.get();
		System.out.println(max2.getValue());
	}

}
