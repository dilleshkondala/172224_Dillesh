package com.cpgm.fruitClient;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import com.cpgm.streamspojo.Fruit;

public class ColorWiseFruits {

	public static void main(String[] args) {
		
		List<Fruit> fruitList = new ArrayList<>();
		fruitList.add(new Fruit("Banana",100,10,"Yellow"));
		fruitList.add(new Fruit("Guava",120,20,"Green"));
		fruitList.add(new Fruit("Apple",70,30,"Red"));
		fruitList.add(new Fruit("Grapes",20,30,"Violet"));
		fruitList.add(new Fruit("Orange",50,30,"Yellow"));
		fruitList.add(new Fruit("PineApple",90,30,"Orange"));
		fruitList.add(new Fruit("Pomegranate",90,30,"Red"));
		fruitList.add(new Fruit("Strawberry",90,30,"Red"));
		
		fruitList.forEach(System.out::println);
		System.out.println("******************************************************************************");
		
		List<String> colorList = fruitList.stream().sorted(Comparator.comparing(Fruit :: getColor))
				.map(Fruit :: getName).collect(Collectors.toList());
		colorList.forEach(System.out::println);
		
		System.out.println("******************************************************************************");
	}

}
