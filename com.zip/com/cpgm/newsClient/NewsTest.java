package com.cpgm.newsClient;

import java.util.ArrayList;
import java.util.List;

import com.cpgm.streamspojo.News;


public class NewsTest {

	public static void main(String[] args) {

		List<News> newsList = new ArrayList<>();
		newsList.add(new News(101,"This is ","dfdsfedsfds","fddsfdsf"));
		newsList.add(new News(101,"fdsdsfdsf","dfdsfedsfds","fddsfdsf"));
		newsList.add(new News(101,"fdsdsfdsf","dfdsfedsfds","fddsfdsf"));
		newsList.add(new News(101,"fdsdsfdsf","dfdsfedsfds","fddsfdsf"));
		newsList.add(new News(101,"fdsdsfdsf","dfdsfedsfds","fddsfdsf"));
		newsList.add(new News(101,"fdsdsfdsf","dfdsfedsfds","fddsfdsf"));
		
		
	}

}
